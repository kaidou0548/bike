// src/controllers/gerencianet.d.ts
declare module 'gerencianet' {
    const Gerencianet: any;
    export { Gerencianet };
}

